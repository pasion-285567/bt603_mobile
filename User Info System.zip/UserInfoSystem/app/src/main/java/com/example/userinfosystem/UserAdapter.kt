package com.example.userinfosystem

class UserAdapter {
}