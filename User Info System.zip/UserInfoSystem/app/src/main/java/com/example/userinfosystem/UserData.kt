package com.example.userinfosystem

data class UserData(
    val id: Long = 0,
    val name: String = "",
    val age: Int = 0,
    val contact: String = "",
    val email: String = ""
)